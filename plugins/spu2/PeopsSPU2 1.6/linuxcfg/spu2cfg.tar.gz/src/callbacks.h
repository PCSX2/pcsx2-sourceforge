#include <gtk/gtk.h>


void
on_CfgWnd_destroy                      (GtkObject       *object,
                                        gpointer         user_data);

void
on_btnOK_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_btnCancel_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_btnAClose_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_AboutWnd_destroy                    (GtkObject       *object,
                                        gpointer         user_data);
