#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"

void SaveConfig(void);

void
on_CfgWnd_destroy                      (GtkObject       *object,
                                        gpointer         user_data)
{
 exit(0);
}


void
on_btnOK_clicked                       (GtkButton       *button,
                                        gpointer         user_data)
{
 SaveConfig();
 exit(0);
}


void
on_btnCancel_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
 exit(0);
}


void
on_btnAClose_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
 exit(0);
}


void
on_AboutWnd_destroy                    (GtkObject       *object,
                                        gpointer         user_data)
{
 exit(0);
}

